# Mundo aberto de teste (Godot + mapa BSP convertido)

## Estrutura
- `game/`   projeto Godot 4.3 (mapa já convertido em `game/map/`)
- `tools/bsp2obj.py`   conversor BSP -> OBJ (usado só se quiser reconverter)
- `.github/workflows/build-apk.yml`   gera o APK
- `.github/workflows/converter-mapa.yml`   só converte o mapa (opcional, com recorte)

## Gerar o APK (pelo Termux)
1. `git init`, `git add .`, `git commit -m "jogo"`, crie o repositório no GitHub e `git push`.
2. GitHub > Actions > "Gerar APK (Godot)" > Run workflow.
3. Quando terminar, baixe o artifact `jogo-apk`, extraia e instale `jogo.apk`.

(O `.bsp` é opcional: se colocar em `maps/rp_downtown_vv1.bsp`, o workflow reconverte.)

## Controles
- Esquerda da tela: analógico (andar / acelerar e virar no carro)
- Direita da tela: arrastar para girar a câmera
- Botões: Pular, Entrar/Sair (perto do carro), Resetar carro
- No PC: WASD e arrastar com o mouse

## Ajustes rápidos
- Carro andando de ré ou direção invertida: `DRIVE_SIGN` / `STEER_SIGN` em `game/car.gd`
- Ponto de início: `SPAWN` em `game/main.gd`

## Texturas
O conversor usa texturas procedurais de `tools/textures/` (tijolo, pedra, concreto, madeira,
metal, vidro, fachadas, vitrines...) escolhidas pelo nome do material. Para regerá-las:
`pip install numpy pillow && python tools/make_textures.py`.
Se você tiver as texturas reais do jogo, coloque numa pasta `content/` (com `materials/`) e use `--content`.

## Desempenho
Se ficar pesado no celular, em `game/main.gd` troque `SHADOWS` para `false`.

## Cidade ao redor do mapa
`tools/gen_city.py` gera uma cidade de ~1 km x 1 km em volta do mapa: ruas com faixas, calçadas,
faixas de pedestres, quarteirões com prédios de vários estilos, parques, árvores, postes,
semáforos, hidrantes, bancos e carros estacionados. O resultado fica em `game/city/`
(pedaços `city_solid_*` com colisão e `city_deco_*` sem colisão) e `game/traffic.gd` coloca
carros e pedestres andando pelas ruas.

Para regerar (opcional): `pip install numpy pillow`,
`python tools/make_textures.py && python tools/make_city_textures.py`,
`python tools/gen_city.py game/map/rp_downtown_vv1.obj game/city`.

Ajustes: `K` (camadas de quarteirões, deixa a cidade maior ou menor), `SEED` (muda a cidade)
e as faixas de andares por região, no começo e no meio de `tools/gen_city.py`.

## Extras do jogo (cada um é um script opcional em `game/`)
- `hud.gd`: mini-mapa no canto superior esquerdo, relógio, dinheiro, missão e velocidade
- `daynight.gd`: ciclo de dia e noite (8 min reais; mude `DAY_SECONDS`), postes acendem e o carro liga os faróis
- `missions.gd`: entregas, vá até o marcador amarelo e ganhe $100
- `traffic.gd`: carros e pedestres andando pelas ruas

## Cidade grande e estradas (versão 2)
- A cidade tem ~1,6 km x 1,6 km (`K = 8` em `tools/gen_city.py`), com colinas ao fundo.
- A cada 4ª rua há uma avenida de 32 m, com 4 faixas, canteiro central arborizado e estacionamento nas laterais.
- Cruzamentos com faixa de pedestres e linha de parada; asfalto com remendos, rachaduras e bueiros.
- Árvores, postes, carros e semáforos só existem até `PROP_R` (520 m) do mapa, para não pesar no celular.
