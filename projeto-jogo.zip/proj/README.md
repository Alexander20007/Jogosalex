# Mundo aberto de teste (Godot + mapa BSP convertido)

## Estrutura
- `game/`   projeto Godot 4.3 (mapa já convertido em `game/map/`)
- `tools/bsp2obj.py`   conversor BSP -> OBJ (usado só se quiser reconverter)
- `.github/workflows/build-apk.yml`   gera o APK
- `.github/workflows/converter-mapa.yml`   só converte o mapa (opcional, com recorte)

## Gerar o APK (pelo Termux)
1. `git init`, `git add .`, `git commit -m "jogo"`, crie o repositório no GitHub e `git push`.
2. GitHub > Actions > "Gerar APK (Godot)" > Run workflow.
3. Quando terminar, baixe o artifact `jogo-apk`, extraia e instale `jogo.apk`.

(O `.bsp` é opcional: se colocar em `maps/rp_downtown_vv1.bsp`, o workflow reconverte.)

## Controles
- Esquerda da tela: analógico (andar / acelerar e virar no carro)
- Direita da tela: arrastar para girar a câmera
- Botões: Pular, Entrar/Sair (perto do carro), Resetar carro
- No PC: WASD e arrastar com o mouse

## Ajustes rápidos
- Carro andando de ré ou direção invertida: `DRIVE_SIGN` / `STEER_SIGN` em `game/car.gd`
- Ponto de início: `SPAWN` em `game/main.gd`
