#!/usr/bin/env python3
"""Gera texturas procedurais (512x512, repetíveis) em tools/textures/. Requer numpy + pillow.
Cada textura cobre ~2,4 m no mundo (a mesma escala das texturas originais da Source)."""
import os
import numpy as np
from PIL import Image

N = 512
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "textures")
os.makedirs(OUT, exist_ok=True)
yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)


def fnoise(beta=2.0, seed=None):
    """Ruído repetível (filtrado em frequência), valores 0..1."""
    r = np.random.default_rng(seed) if seed is not None else rng
    F = np.fft.fft2(r.normal(size=(N, N)))
    fx = np.fft.fftfreq(N)[None, :]
    fy = np.fft.fftfreq(N)[:, None]
    f = np.sqrt(fx ** 2 + fy ** 2)
    f[0, 0] = 1.0
    F = F / (f ** (beta / 2.0))
    F[0, 0] = 0
    out = np.real(np.fft.ifft2(F))
    out = (out - out.min()) / (out.max() - out.min() + 1e-9)
    return out.astype(np.float32)


def streaks(horizontal=True, sigma=0.012):
    """Ruído alongado (fibras de madeira / metal escovado)."""
    F = np.fft.fft2(rng.normal(size=(N, N)))
    fx = np.fft.fftfreq(N)[None, :]
    fy = np.fft.fftfreq(N)[:, None]
    g = np.exp(-(fx ** 2 if horizontal else fy ** 2) / (2 * sigma ** 2))
    out = np.real(np.fft.ifft2(F * g))
    out = (out - out.min()) / (out.max() - out.min() + 1e-9)
    return out.astype(np.float32)


def rgb(c):
    return np.array(c, dtype=np.float32)[None, None, :]


def save(name, img):
    img = np.clip(img, 0, 1)
    Image.fromarray((img * 255).astype(np.uint8)).save(os.path.join(OUT, name + ".png"), optimize=True)
    print("ok", name)


def shade(base, amount=0.25, beta=2.2, fine=0.06):
    n = fnoise(beta)
    f = fnoise(0.5)
    return base * (1 - amount / 2 + amount * n[..., None] + fine * (f[..., None] - 0.5))


def concrete():
    img = shade(rgb((0.56, 0.56, 0.54)), 0.22, 2.4, 0.10)
    stains = fnoise(3.2)[..., None]
    return img * (0.88 + 0.2 * stains)


def plaster():
    img = shade(rgb((0.84, 0.80, 0.72)), 0.12, 2.6, 0.05)
    return img * (0.92 + 0.12 * fnoise(3.5)[..., None])


def asphalt():
    img = shade(rgb((0.17, 0.17, 0.18)), 0.12, 1.2, 0.18)
    peb = (rng.random((N, N)) > 0.985).astype(np.float32)[..., None] * 0.18
    return img + peb


def grass():
    base = shade(rgb((0.27, 0.43, 0.17)), 0.35, 1.6, 0.25)
    return base * (0.9 + 0.2 * fnoise(0.8)[..., None])


def water():
    n = fnoise(2.8)[..., None]
    return rgb((0.12, 0.32, 0.52)) * (0.8 + 0.5 * n)


def carpet():
    img = shade(rgb((0.36, 0.12, 0.13)), 0.18, 0.4, 0.2)
    return img


def brick():
    rows, per_row = 32, 10
    ch = N / rows
    bw = N / per_row
    row = np.floor(yy / ch)
    off = (row % 2) * (bw / 2)
    xs = (xx + off) % N
    col = np.floor(xs / bw)
    bx, by = xs - col * bw, yy - row * ch
    mortar = (bx < 2.5) | (by < 2.5)
    var = rng.random((rows, per_row)).astype(np.float32)
    v = var[row.astype(int), col.astype(int)]
    base = rgb((0.50, 0.22, 0.16)) * (0.78 + 0.45 * v[..., None])
    base = base * (0.85 + 0.3 * fnoise(1.5)[..., None])
    mort = rgb((0.66, 0.64, 0.60)) * (0.9 + 0.2 * fnoise(0.5)[..., None])
    return np.where(mortar[..., None], mort, base)


def stone():
    rows, per_row = 8, 4
    ch = N / rows
    bw = N / per_row
    row = np.floor(yy / ch)
    off = (row % 2) * (bw / 2)
    xs = (xx + off) % N
    col = np.floor(xs / bw)
    bx, by = xs - col * bw, yy - row * ch
    joint = (bx < 3) | (by < 3)
    var = rng.random((rows, per_row)).astype(np.float32)
    v = var[row.astype(int), col.astype(int)]
    base = rgb((0.60, 0.57, 0.50)) * (0.8 + 0.35 * v[..., None])
    base = base * (0.8 + 0.4 * fnoise(2.2)[..., None])
    return np.where(joint[..., None], rgb((0.25, 0.24, 0.22)), base)


def tile():
    cell = N / 8
    cx, cy = xx % cell, yy % cell
    grout = (cx < 2.5) | (cy < 2.5)
    var = rng.random((8, 8)).astype(np.float32)
    v = var[(yy // cell).astype(int), (xx // cell).astype(int)]
    base = rgb((0.88, 0.90, 0.90)) * (0.94 + 0.08 * v[..., None])
    base = base * (0.97 + 0.05 * fnoise(0.5)[..., None])
    return np.where(grout[..., None], rgb((0.5, 0.52, 0.52)), base)


def metal():
    s = streaks(True, 0.008)[..., None]
    img = rgb((0.50, 0.53, 0.57)) * (0.75 + 0.35 * s)
    img = img * (0.92 + 0.12 * fnoise(2.0)[..., None])
    seam = ((yy % 256) < 2.5) | ((xx % 256) < 2.5)
    img = np.where(seam[..., None], img * 0.55, img)
    rivets = ((xx % 64 - 32) ** 2 + (yy % 256 - 12) ** 2) < 9
    return np.where(rivets[..., None], img * 1.25, img)


def wood():
    planks = 4
    pw = N / planks
    col = np.floor(xx / pw).astype(int)
    pv = rng.random(planks).astype(np.float32)[col]
    s = streaks(False, 0.015)
    grain = (0.65 + 0.5 * s)
    base = rgb((0.46, 0.29, 0.15)) * (0.75 + 0.4 * pv[..., None]) * grain[..., None]
    gap = (xx % pw) < 2.5
    return np.where(gap[..., None], rgb((0.12, 0.08, 0.05)), base)


def glass():
    g = (yy / N)[..., None]
    base = rgb((0.55, 0.72, 0.82)) * (1.0 - 0.45 * g) + rgb((0.1, 0.12, 0.15)) * g * 0.3
    streak = np.exp(-(((xx + yy) % N - 150) ** 2) / (2 * 28 ** 2))[..., None] * 0.18
    return base + streak + 0.03 * fnoise(1.0)[..., None]


def window_block(img, x0, y0, x1, y1, frame=12, bars=True):
    """Desenha moldura + vidro azulado numa região."""
    img[y0:y1, x0:x1] = rgb((0.88, 0.87, 0.84))
    gx0, gy0, gx1, gy1 = x0 + frame, y0 + frame, x1 - frame, y1 - frame
    h = gy1 - gy0
    grad = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
    glass_c = rgb((0.38, 0.52, 0.64)) * (1 - grad) + rgb((0.10, 0.16, 0.24)) * grad
    img[gy0:gy1, gx0:gx1] = glass_c
    gw = gx1 - gx0
    streak = np.exp(-((np.arange(gw)[None, :] + np.arange(h)[:, None] - gw * 0.6) ** 2) / (2 * 22 ** 2))
    img[gy0:gy1, gx0:gx1] += streak[..., None].astype(np.float32) * 0.15
    if bars:
        mx = (gx0 + gx1) // 2
        my = (gy0 + gy1) // 2
        img[gy0:gy1, mx - 3:mx + 3] = rgb((0.88, 0.87, 0.84))
        img[my - 3:my + 3, gx0:gx1] = rgb((0.88, 0.87, 0.84))
    return img


def facade():
    img = plaster() * rgb((0.95, 0.9, 0.85))
    img = img.copy()
    img[84:96, 136:376] = rgb((0.62, 0.60, 0.56))      # verga
    img = window_block(img, 150, 96, 362, 380, 12, True)
    img[380:394, 136:376] = rgb((0.78, 0.76, 0.72))    # peitoril
    img[394:400, 140:372] = rgb((0.45, 0.43, 0.40))    # sombra do peitoril
    return img


def storefront():
    img = np.zeros((N, N, 3), np.float32) + rgb((0.20, 0.17, 0.15))
    img[0:84] = rgb((0.30, 0.24, 0.20)) * (0.9 + 0.2 * fnoise(2.0)[0:84, :, None])  # faixa do letreiro
    img[440:N] = rgb((0.26, 0.26, 0.27)) * (0.9 + 0.2 * fnoise(2.0)[440:N, :, None])  # rodapé
    img[96:440, 16:496] = rgb((0.1, 0.09, 0.08))
    img = window_block(img, 16, 96, 496, 440, 14, False)
    mx = 256
    img[110:426, mx - 4:mx + 4] = rgb((0.18, 0.15, 0.13))  # divisória central
    return img


TEX = dict(concrete=concrete, plaster=plaster, asphalt=asphalt, grass=grass, water=water,
           carpet=carpet, brick=brick, stone=stone, tile=tile, metal=metal, wood=wood,
           glass=glass, facade=facade, storefront=storefront)

if __name__ == "__main__":
    for k, fn in TEX.items():
        save(k, fn())
