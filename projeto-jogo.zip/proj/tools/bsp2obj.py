#!/usr/bin/env python3
"""
bsp2obj.py - converte um mapa Source (VBSP) em OBJ + MTL + texturas PNG.

Uso:
  python tools/bsp2obj.py mapa.bsp saida/
  python tools/bsp2obj.py mapa.bsp saida/ --center 0 0 --radius 6000
  python tools/bsp2obj.py mapa.bsp saida/ --content pasta_com_materials/

Requer: Python 3.8+ e Pillow (pip install pillow).
"""
import argparse
import colorsys
import hashlib
import io
import os
import re
import struct
import zipfile

from PIL import Image

SCALE = 0.01905  # 1 unidade Source ~ 1,905 cm

SKIP_FLAGS = 0x2 | 0x4 | 0x40 | 0x80 | 0x100 | 0x200  # sky, trigger, nodraw, hint, skip
LUMP_ENTITIES, LUMP_TEXDATA, LUMP_VERTEXES = 0, 2, 3
LUMP_TEXINFO, LUMP_FACES, LUMP_EDGES, LUMP_SURFEDGES = 6, 7, 12, 13
LUMP_MODELS, LUMP_PAKFILE = 14, 40
LUMP_STRTABLE, LUMP_STRDATA = 44, 43


def lump(data, i):
    off, length, _ver, _cc = struct.unpack_from("<iiii", data, 8 + i * 16)
    return data[off:off + length]


# ---------------------------------------------------------------- VTF -> PNG
def _build_dds(width, height, fourcc, payload):
    h = bytearray()
    h += b"DDS "
    h += struct.pack("<7I", 124, 0x1007 | 0x80000, height, width, len(payload), 0, 0)
    h += b"\0" * 44
    h += struct.pack("<II4sIIIII", 32, 4, fourcc, 0, 0, 0, 0, 0)
    h += struct.pack("<IIIII", 0x1000, 0, 0, 0, 0)
    return bytes(h) + payload


def vtf_to_image(raw, max_size=1024):
    if raw[:4] != b"VTF\0":
        raise ValueError("não é VTF")
    hsize = struct.unpack_from("<I", raw, 12)[0]
    w, h = struct.unpack_from("<HH", raw, 16)
    fmt = struct.unpack_from("<i", raw, 52)[0]
    mips = raw[56]

    def size_of(f, ww, hh):
        if f == 13:  # DXT1
            return max(1, (ww + 3) // 4) * max(1, (hh + 3) // 4) * 8
        if f in (14, 15):  # DXT3 / DXT5
            return max(1, (ww + 3) // 4) * max(1, (hh + 3) // 4) * 16
        bpp = {0: 4, 1: 4, 2: 3, 3: 3, 12: 4, 11: 4, 8: 1, 5: 1}.get(f)
        if bpp is None:
            raise ValueError(f"formato VTF {fmt} não suportado")
        return ww * hh * bpp

    n = size_of(fmt, w, h)
    data = raw[-n:]  # maior mipmap fica no fim do arquivo
    if fmt in (13, 14, 15):
        cc = {13: b"DXT1", 14: b"DXT3", 15: b"DXT5"}[fmt]
        img = Image.open(io.BytesIO(_build_dds(w, h, cc, data))).convert("RGBA")
    elif fmt == 0:
        img = Image.frombytes("RGBA", (w, h), data)
    elif fmt == 1:
        img = Image.frombytes("RGBA", (w, h), data, "raw", "ABGR")
    elif fmt == 2:
        img = Image.frombytes("RGB", (w, h), data).convert("RGBA")
    elif fmt == 3:
        img = Image.frombytes("RGB", (w, h), data, "raw", "BGR").convert("RGBA")
    elif fmt in (11, 12):
        img = Image.frombytes("RGBA", (w, h), data, "raw", "BGRA")
    elif fmt in (5, 8):
        img = Image.frombytes("L", (w, h), data).convert("RGBA")
    else:
        raise ValueError(f"formato VTF {fmt} não suportado")
    if max(img.size) > max_size:
        img.thumbnail((max_size, max_size))
    return img


# ------------------------------------------------------------------ materiais
class Content:
    """Procura arquivos de material no pakfile do mapa e em pastas extras."""

    def __init__(self, pak_bytes, extra_dirs):
        self.zip = None
        self.names = {}
        if pak_bytes:
            try:
                self.zip = zipfile.ZipFile(io.BytesIO(pak_bytes))
                self.names = {n.lower(): n for n in self.zip.namelist()}
            except zipfile.BadZipFile:
                pass
        self.extra = extra_dirs

    def read(self, path):
        path = path.lower().replace("\\", "/")
        if path in self.names:
            return self.zip.read(self.names[path])
        for d in self.extra:
            p = os.path.join(d, path)
            if os.path.isfile(p):
                return open(p, "rb").read()
            # tenta ignorar maiúsculas/minúsculas
            cur = d
            ok = True
            for part in path.split("/"):
                try:
                    match = next(x for x in os.listdir(cur) if x.lower() == part)
                except (StopIteration, FileNotFoundError, NotADirectoryError):
                    ok = False
                    break
                cur = os.path.join(cur, match)
            if ok and os.path.isfile(cur):
                return open(cur, "rb").read()
        return None


def resolve_texture(content, matname):
    """matname -> bytes do VTF (ou None)."""
    name = matname.lower().replace("\\", "/")
    vmt = content.read(f"materials/{name}.vmt")
    base = None
    if vmt:
        txt = vmt.decode("latin1")
        m = re.search(r'"?\$basetexture"?\s+"?([^"\s]+)"?', txt, re.I)
        if m:
            base = m.group(1).replace("\\", "/")
        else:
            m = re.search(r'"?include"?\s+"?([^"\s]+\.vmt)"?', txt, re.I)
            if m:  # patch material
                return resolve_texture(content, re.sub(r"^materials/|\.vmt$", "", m.group(1), flags=re.I))
    for cand in (base, name):
        if cand:
            vtf = content.read(f"materials/{cand}.vtf")
            if vtf:
                return vtf
    return None


COLOR_HINTS = [
    (("brick",), (0.62, 0.32, 0.26)),
    (("wood", "plywood", "door", "floor_wood"), (0.55, 0.38, 0.22)),
    (("metal", "steel", "iron", "pipe"), (0.45, 0.50, 0.55)),
    (("glass", "window"), (0.55, 0.72, 0.85)),
    (("road", "asphalt", "street", "blacktop"), (0.18, 0.18, 0.20)),
    (("grass", "nature", "dirt", "ground", "sand"), (0.35, 0.50, 0.27)),
    (("tile", "plaster", "wall", "storefront"), (0.80, 0.78, 0.72)),
    (("concrete", "stone", "cement", "pavement", "sidewalk", "rock"), (0.58, 0.58, 0.56)),
    (("water",), (0.25, 0.45, 0.70)),
]


def fallback_color(name):
    """Sem textura: cor aproximada pelo nome do material (tijolo, madeira...)."""
    low = name.lower()
    for keys, color in COLOR_HINTS:
        if any(k in low for k in keys):
            h = int(hashlib.md5(name.encode()).hexdigest()[:2], 16) / 255.0
            shade = 0.9 + 0.2 * h  # variação leve entre materiais parecidos
            return tuple(min(1.0, c * shade) for c in color)
    h = int(hashlib.md5(name.encode()).hexdigest()[:6], 16)
    return colorsys.hsv_to_rgb((h % 360) / 360.0, 0.25, 0.75)


TEX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "textures")

CATEGORY_RULES = [
    (("storefront",), "storefront"),
    (("building_template",), "facade"),
    (("brick",), "brick"),
    (("stone", "rock", "cobble"), "stone"),
    (("asphalt", "road", "street", "blacktop"), "asphalt"),
    (("concrete", "cement", "pavement", "sidewalk"), "concrete"),
    (("plaster", "wallpaper", "drywall"), "plaster"),
    (("metal", "steel", "iron", "combine", "truss", "stainless", "pipe", "vent"), "metal"),
    (("wood", "plywood", "board", "stair"), "wood"),
    (("glass", "window"), "glass"),
    (("tile",), "tile"),
    (("grass", "nature", "dirt", "ground", "sand"), "grass"),
    (("carpet",), "carpet"),
    (("water",), "water"),
]
SHADES = (0.78, 0.89, 1.0)


def classify(name):
    low = name.lower()
    for keys, cat in CATEGORY_RULES:
        if any(k in low for k in keys):
            return cat
    return "plaster"


# ----------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bsp")
    ap.add_argument("out")
    ap.add_argument("--center", nargs=2, type=float, metavar=("X", "Y"),
                    help="recorta ao redor deste ponto (unidades Source)")
    ap.add_argument("--radius", type=float, default=0,
                    help="raio do recorte (unidades Source)")
    ap.add_argument("--content", action="append", default=[],
                    help="pasta extra com materials/ (ex.: conteúdo do HL2)")
    ap.add_argument("--max-tex", type=int, default=1024)
    args = ap.parse_args()

    data = open(args.bsp, "rb").read()
    if data[:4] != b"VBSP":
        raise SystemExit("arquivo não é um BSP da Source")
    print("versão BSP:", struct.unpack_from("<i", data, 4)[0])

    verts = [struct.unpack_from("<3f", lump(data, LUMP_VERTEXES), i * 12)
             for i in range(len(lump(data, LUMP_VERTEXES)) // 12)]
    edges_raw = lump(data, LUMP_EDGES)
    edges = [struct.unpack_from("<HH", edges_raw, i * 4) for i in range(len(edges_raw) // 4)]
    se_raw = lump(data, LUMP_SURFEDGES)
    surfedges = struct.unpack("<%di" % (len(se_raw) // 4), se_raw)

    td_raw = lump(data, LUMP_TEXDATA)
    str_tab = struct.unpack("<%di" % (len(lump(data, LUMP_STRTABLE)) // 4), lump(data, LUMP_STRTABLE))
    str_data = lump(data, LUMP_STRDATA)

    def tex_name(sid):
        off = str_tab[sid]
        return str_data[off:str_data.index(b"\0", off)].decode("latin1").lower()

    texdata = []
    for i in range(len(td_raw) // 32):
        _rx, _ry, _rz, sid, tw, th, _vw, _vh = struct.unpack_from("<3fiiiii", td_raw, i * 32)
        texdata.append((tex_name(sid), max(tw, 1), max(th, 1)))

    ti_raw = lump(data, LUMP_TEXINFO)
    texinfo = []
    for i in range(len(ti_raw) // 72):
        f = struct.unpack_from("<16f2i", ti_raw, i * 72)
        texinfo.append((f[0:4], f[4:8], f[16], f[17]))

    faces_raw = lump(data, LUMP_FACES)
    models_raw = lump(data, LUMP_MODELS)
    first_face, num_faces = struct.unpack_from("<ii", models_raw, 40)  # modelo 0 = mundo

    pak = lump(data, LUMP_PAKFILE)
    content = Content(pak, args.content)

    os.makedirs(os.path.join(args.out, "tex"), exist_ok=True)

    key_info = {}
    name_cache = {}

    def get_info(name):
        if name in name_cache:
            return name_cache[name]
        raw = resolve_texture(content, name)
        if raw is not None:
            inf = {"raw": raw, "key": re.sub(r"[^a-z0-9_]+", "_", name), "cat": None, "shade": 1.0}
        else:
            cat = classify(name)
            bucket = int(hashlib.md5(name.encode()).hexdigest()[:2], 16) % len(SHADES)
            inf = {"raw": None, "key": f"p_{cat}_{bucket}", "cat": cat, "shade": SHADES[bucket]}
        name_cache[name] = inf
        key_info[inf["key"]] = inf
        return inf

    by_mat = {}  # material -> lista de (posições, uvs)
    skipped = {"flags": 0, "disp": 0, "crop": 0, "tools": 0}
    for fi in range(first_face, first_face + num_faces):
        (_pl, _side, _node, firstedge, numedges, tinfo, dispinfo,
         *_rest) = struct.unpack_from("<HBBiHhhh", faces_raw, fi * 56)
        if tinfo < 0:
            continue
        vu, vv, flags, tdi = texinfo[tinfo]
        name, tw, th = texdata[tdi]
        if flags & SKIP_FLAGS:
            skipped["flags"] += 1
            continue
        if name.startswith("tools/"):
            skipped["tools"] += 1
            continue
        if dispinfo >= 0:
            skipped["disp"] += 1  # terreno/displacement ainda não suportado
            continue
        poly = []
        for k in range(firstedge, firstedge + numedges):
            se = surfedges[k]
            a, b = edges[se] if se >= 0 else edges[-se][::-1]
            poly.append(verts[a])
        if len(poly) < 3:
            continue
        if args.radius > 0 and args.center:
            cx = sum(p[0] for p in poly) / len(poly)
            cy = sum(p[1] for p in poly) / len(poly)
            if (cx - args.center[0]) ** 2 + (cy - args.center[1]) ** 2 > args.radius ** 2:
                skipped["crop"] += 1
                continue
        info = get_info(name)
        ntw, nth = (tw, th) if info["raw"] is not None else (512.0, 512.0)
        uvs = []
        for (x, y, z) in poly:
            u = (x * vu[0] + y * vu[1] + z * vu[2] + vu[3]) / ntw
            v = (x * vv[0] + y * vv[1] + z * vv[2] + vv[3]) / nth
            uvs.append((u, -v))
        by_mat.setdefault(info["key"], []).append((poly, uvs))

    # texturas e materiais
    mtl_lines = []
    found = proc = missing = 0
    copied = set()
    for key in sorted(by_mat):
        inf = key_info[key]
        mtl_lines.append(f"newmtl {key}")
        mtl_lines.append("Ka 1 1 1")
        png = None
        shade = 1.0
        if inf["raw"] is not None:
            try:
                img = vtf_to_image(inf["raw"], args.max_tex)
                png = f"tex/{key}.png"
                img.save(os.path.join(args.out, png))
                found += 1
            except Exception as e:  # noqa: BLE001
                print("  falha na textura", key, "->", e)
        else:
            src = os.path.join(TEX_DIR, inf["cat"] + ".png")
            if os.path.isfile(src):
                png = f"tex/p_{inf['cat']}.png"
                if inf["cat"] not in copied:
                    Image.open(src).save(os.path.join(args.out, png))
                    copied.add(inf["cat"])
                shade = inf["shade"]
                proc += 1
        if png:
            mtl_lines.append(f"Kd {shade:.3f} {shade:.3f} {shade:.3f}")
            mtl_lines.append(f"map_Kd {png}")
        else:
            missing += 1
            r, g, b = fallback_color(key)
            mtl_lines.append(f"Kd {r:.3f} {g:.3f} {b:.3f}")
        mtl_lines.append("")

    base = os.path.splitext(os.path.basename(args.bsp))[0]
    with open(os.path.join(args.out, base + ".mtl"), "w") as f:
        f.write("\n".join(mtl_lines))

    # OBJ (Z-up Source -> Y-up, metros)
    nv = 0
    ntris = 0
    with open(os.path.join(args.out, base + ".obj"), "w") as f:
        f.write(f"mtllib {base}.mtl\n")
        for name in sorted(by_mat):
            safe = name
            f.write(f"o {safe}\nusemtl {safe}\n")
            for poly, uvs in by_mat[name]:
                for (x, y, z), (u, v) in zip(poly, uvs):
                    f.write(f"v {x * SCALE:.4f} {z * SCALE:.4f} {-y * SCALE:.4f}\n")
                    f.write(f"vt {u:.4f} {v:.4f}\n")
                n = len(poly)
                # Source usa ordem horária; OBJ espera anti-horária -> inverte
                idx = list(range(nv + n, nv, -1))
                for i in range(1, n - 1):
                    a, b, c = idx[0], idx[i], idx[i + 1]
                    f.write(f"f {a}/{a} {b}/{b} {c}/{c}\n")
                    ntris += 1
                nv += n

    print(f"materiais: {len(by_mat)} (VTF reais: {found}, procedurais: {proc}, sem textura: {missing})")
    print(f"vértices: {nv}, triângulos: {ntris}")
    print("faces ignoradas:", skipped)
    print("saída em:", args.out)


if __name__ == "__main__":
    main()
