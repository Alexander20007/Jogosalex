#!/usr/bin/env python3
"""Gera as texturas da cidade em tools/textures_city/. Requer numpy + pillow.
Prédios: cada textura cobre 6,4 m x 6,4 m (2 andares de 3,2 m, 2 janelas por andar)."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_textures as mt  # noqa: E402
from make_textures import N, rgb, fnoise, shade, yy, xx, rng  # noqa: E402
from PIL import Image  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "textures_city")
os.makedirs(OUT, exist_ok=True)


def save(name, img):
    img = np.clip(img, 0, 1)
    Image.fromarray((img * 255).astype(np.uint8)).save(os.path.join(OUT, name + ".png"), optimize=True)
    print("ok", name)


def rect(img, x0, y0, x1, y1, color):
    img[y0:y1, x0:x1] = color


def _wear(img, seed):
    """Remendos, rachaduras e bueiros no asfalto (img: array HxWx3 em 0..1)."""
    from PIL import ImageDraw
    r = np.random.default_rng(seed)
    pil = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    d = ImageDraw.Draw(pil, "RGBA")
    for _ in range(5):                      # remendos
        x, y = int(r.integers(0, N - 90)), int(r.integers(0, N - 90))
        w, h = int(r.integers(40, 90)), int(r.integers(30, 80))
        d.rectangle([x, y, x + w, y + h], fill=(14, 14, 15, 70))
    for _ in range(7):                      # rachaduras
        x, y = float(r.integers(0, N)), float(r.integers(0, N))
        pts = [(x, y)]
        for _k in range(int(r.integers(4, 9))):
            x += float(r.normal(0, 18))
            y += float(r.normal(0, 18))
            pts.append((x, y))
        d.line(pts, fill=(8, 8, 9, 200), width=1)
    for _ in range(2):                      # bueiros
        x, y = int(r.integers(60, N - 60)), int(r.integers(60, N - 60))
        d.ellipse([x - 16, y - 16, x + 16, y + 16], fill=(38, 38, 40, 255), outline=(20, 20, 22, 255))
        d.ellipse([x - 11, y - 11, x + 11, y + 11], outline=(60, 60, 62, 255))
    return np.asarray(pil).astype(np.float32) / 255.0


def road():
    # rua local: 14 m de largura = 512 px (36,6 px/m); u atravessa a rua
    img = mt.asphalt() * 1.0
    ppm = N / 14.0

    def line(xc_m, w_m, color):
        a = int((xc_m - w_m / 2) * ppm)
        b = int((xc_m + w_m / 2) * ppm) + 1
        img[:, a:b] = color * (0.9 + 0.1 * fnoise(0.5)[:, a:b, None])

    white, yellow = rgb((0.85, 0.85, 0.82)), rgb((0.85, 0.68, 0.12))
    for xc in (3.8, 5.7, 8.3, 10.2):        # desgaste de pneus
        a, b = int((xc - 0.35) * ppm), int((xc + 0.35) * ppm)
        img[:, a:b] *= 0.93
    img = _wear(img, 11)
    line(2.5, 0.15, white)
    line(11.5, 0.15, white)
    line(6.85, 0.12, yellow)
    line(7.15, 0.12, yellow)
    dash = ((yy // 64) % 2 == 0)
    for xc in (4.75, 9.25):
        a, b = int((xc - 0.07) * ppm), int((xc + 0.07) * ppm) + 1
        sel = dash[:, a:b, None]
        img[:, a:b] = np.where(sel, white * 0.9, img[:, a:b])
    return img


def avenue():
    # avenida: 24 m = 512 px (21,3 px/m): estacionamento 2,5 | 2 faixas de 4 | canteiro 2 | 2 faixas | 2,5
    img = mt.asphalt() * 1.0
    ppm = N / 24.0

    def line(xc_m, w_m, color):
        a = int((xc_m - w_m / 2) * ppm)
        b = int((xc_m + w_m / 2) * ppm) + 1
        img[:, a:b] = color * (0.9 + 0.1 * fnoise(0.5)[:, a:b, None])

    white, yellow = rgb((0.85, 0.85, 0.82)), rgb((0.85, 0.68, 0.12))
    for xc in (4.5, 8.5, 15.5, 19.5):
        a, b = int((xc - 0.4) * ppm), int((xc + 0.4) * ppm)
        img[:, a:b] *= 0.93
    img = _wear(img, 23)
    line(2.5, 0.15, white)
    line(21.5, 0.15, white)
    line(10.8, 0.15, yellow)                # ao lado do canteiro (que cobre 11 a 13 m)
    line(13.2, 0.15, yellow)
    dash = ((yy // 64) % 2 == 0)
    for xc in (6.5, 17.5):
        a, b = int((xc - 0.08) * ppm), int((xc + 0.08) * ppm) + 1
        sel = dash[:, a:b, None]
        img[:, a:b] = np.where(sel, white * 0.9, img[:, a:b])
    return img


def crosswalk():
    img = mt.asphalt() * 1.0
    bars = 12
    w = N / (bars * 2)
    idx = (xx // w).astype(int)
    on = (idx % 2 == 0)
    white = rgb((0.88, 0.88, 0.85)) * (0.85 + 0.15 * fnoise(0.8)[..., None])
    return np.where(on[..., None], white, img)


def sidewalk():
    img = mt.concrete() * rgb((1.05, 1.05, 1.03))
    slab = N / 2
    joint = ((xx % slab) < 2.5) | ((yy % slab) < 2.5)
    return np.where(joint[..., None], img * 0.55, img)


def leaves():
    base = mt.shade(rgb((0.20, 0.42, 0.14)), 0.5, 1.2, 0.3)
    spots = (rng.random((N, N)) > 0.97)[..., None] * 0.12
    return base * (0.85 + 0.3 * fnoise(1.0)[..., None]) + spots * rgb((0.3, 0.4, 0.1))


def bark():
    s = mt.streaks(False, 0.02)[..., None]
    return rgb((0.28, 0.19, 0.12)) * (0.6 + 0.8 * s)


def roof():
    img = mt.shade(rgb((0.30, 0.30, 0.31)), 0.18, 0.9, 0.25)
    patches = fnoise(3.0)[..., None]
    return img * (0.9 + 0.2 * patches)


# ------------------------------------------------------------- fachadas
def window(img, cx, cy, w=150, h=140, frame=9, glass=((0.40, 0.55, 0.66), (0.10, 0.17, 0.25)),
           frame_color=(0.88, 0.87, 0.83), sill=True):
    x0, x1, y0, y1 = cx - w // 2, cx + w // 2, cy - h // 2, cy + h // 2
    rect(img, x0, y0, x1, y1, rgb(frame_color))
    gx0, gx1, gy0, gy1 = x0 + frame, x1 - frame, y0 + frame, y1 - frame
    hh = gy1 - gy0
    grad = np.linspace(0, 1, hh, dtype=np.float32)[:, None, None]
    g = rgb(glass[0]) * (1 - grad) + rgb(glass[1]) * grad
    img[gy0:gy1, gx0:gx1] = g
    gw = gx1 - gx0
    streak = np.exp(-((np.arange(gw)[None, :] + np.arange(hh)[:, None] - gw * 0.55) ** 2) / (2 * 18 ** 2))
    img[gy0:gy1, gx0:gx1] += streak[..., None].astype(np.float32) * 0.12
    mx = (gx0 + gx1) // 2
    rect(img, mx - 2, gy0, mx + 2, gy1, rgb(frame_color))
    if sill:
        rect(img, x0 - 8, y1, x1 + 8, y1 + 7, rgb(frame_color) * 0.9)
        rect(img, x0 - 8, y1 + 7, x1 + 8, y1 + 11, rgb(frame_color) * 0.45)
    return img


def two_floor_windows(img, **kw):
    for fy in (128, 384):
        for fx in (128, 384):
            window(img, fx, fy, **kw)
    return img


def b_brick():
    img = mt.brick() * 1.0
    return two_floor_windows(img.copy())


def b_concrete():
    img = mt.concrete() * rgb((1.0, 1.0, 1.02))
    img = img.copy()
    # linhas de junta entre painéis
    rect(img, 0, 0, N, 3, img[0:3] * 0.6)
    rect(img, 0, 255, N, 258, img[255:258] * 0.6)
    return two_floor_windows(img, frame_color=(0.28, 0.30, 0.33), glass=((0.35, 0.5, 0.6), (0.08, 0.12, 0.18)))


def b_office():
    img = mt.plaster() * rgb((1.0, 0.97, 0.9))
    img = img.copy()
    for fy in (128, 384):  # janela corrida
        rect(img, 0, fy - 60, N, fy + 60, rgb((0.2, 0.24, 0.28)))
        grad = np.linspace(0, 1, 112, dtype=np.float32)[:, None, None]
        g = rgb((0.42, 0.58, 0.70)) * (1 - grad) + rgb((0.10, 0.16, 0.24)) * grad
        for px in range(0, N, 128):
            img[fy - 56:fy + 56, px + 6:px + 122] = g
        rect(img, 0, fy + 60, N, fy + 70, rgb((0.82, 0.80, 0.74)))
    return img


def b_glass():
    img = np.zeros((N, N, 3), np.float32)
    panel = 128
    colors = [((0.38, 0.55, 0.66), (0.14, 0.26, 0.36)), ((0.30, 0.48, 0.60), (0.10, 0.20, 0.30)),
              ((0.45, 0.62, 0.72), (0.18, 0.30, 0.40))]
    for gy in range(0, N, panel):
        for gx in range(0, N, panel):
            c = colors[rng.integers(0, 3)]
            grad = np.linspace(0, 1, panel, dtype=np.float32)[:, None, None]
            img[gy:gy + panel, gx:gx + panel] = rgb(c[0]) * (1 - grad) + rgb(c[1]) * grad
    streak = np.exp(-(((xx + yy) % 256 - 110) ** 2) / (2 * 22 ** 2))[..., None] * 0.10
    img = img + streak
    rect(img, 0, 0, N, 5, rgb((0.12, 0.13, 0.15)))          # montantes
    for p in range(0, N, panel):
        rect(img, p, 0, p + 4, N, rgb((0.12, 0.13, 0.15)))
        rect(img, 0, p, N, p + 4, rgb((0.12, 0.13, 0.15)))
    for fy in (0, 256):                                       # faixa opaca entre andares
        rect(img, 0, fy + 224, N, fy + 256, rgb((0.35, 0.37, 0.40)))
    return img


def b_shop():
    img = mt.plaster() * rgb((0.9, 0.86, 0.8))
    img = img.copy()
    # andar térreo = metade inferior (v 0..0.5 -> linhas 256..512 da imagem)
    base = 256
    rect(img, 0, base, N, N, rgb((0.18, 0.16, 0.15)))
    rect(img, 0, base, N, base + 40, rgb((0.32, 0.26, 0.22)))      # faixa do letreiro
    rect(img, 0, N - 26, N, N, rgb((0.24, 0.24, 0.25)))            # rodapé
    for cx in (128, 384):
        x0, x1, y0, y1 = cx - 110, cx + 110, base + 50, N - 30
        rect(img, x0, y0, x1, y1, rgb((0.1, 0.09, 0.08)))
        gh = y1 - y0 - 12
        grad = np.linspace(0, 1, gh, dtype=np.float32)[:, None, None]
        img[y0 + 6:y1 - 6, x0 + 6:x1 - 6] = (rgb((0.42, 0.56, 0.66)) * (1 - grad) + rgb((0.12, 0.18, 0.26)) * grad)
    rect(img, 252, base + 50, 260, N - 30, rgb((0.14, 0.12, 0.1)))
    return img


TEX = dict(road=road, avenue=avenue, crosswalk=crosswalk, sidewalk=sidewalk, leaves=leaves, bark=bark, b_roof=roof,
           b_brick=b_brick, b_concrete=b_concrete, b_office=b_office, b_glass=b_glass, b_shop=b_shop)

if __name__ == "__main__":
    for k, fn in TEX.items():
        save(k, fn())
