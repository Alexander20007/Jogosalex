extends VehicleBody3D
# Carro simples: caixa + 4 rodas. throttle e steer vão de -1 a 1.

# Se o carro andar de ré ao acelerar, troque DRIVE_SIGN para -1.0.
# Se a direção estiver invertida, troque STEER_SIGN para -1.0.
const DRIVE_SIGN := 1.0
const STEER_SIGN := 1.0

var throttle := 0.0
var steer := 0.0
var lights: Array = []


func _init() -> void:
	mass = 900.0
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0, -0.2, 0)
	linear_damp = 0.15

	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.8, 0.7, 4.0)
	col.shape = box
	col.position.y = 0.6
	add_child(col)

	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.75, 0.1, 0.1)
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.8, 0.7, 4.0)
	body.mesh = bm
	body.position.y = 0.6
	body.material_override = body_mat
	add_child(body)

	var cabin := MeshInstance3D.new()
	var cm := BoxMesh.new()
	cm.size = Vector3(1.6, 0.6, 1.8)
	cabin.mesh = cm
	cabin.position = Vector3(0, 1.25, 0.2)
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.25, 0.35, 0.45)
	cabin.material_override = glass
	add_child(cabin)

	for x in [-0.6, 0.6]:
		var l := SpotLight3D.new()
		l.position = Vector3(x, 0.8, -2.1)
		l.spot_range = 45.0
		l.spot_angle = 30.0
		l.light_energy = 4.0
		l.visible = false
		add_child(l)
		lights.append(l)

	for x in [-0.95, 0.95]:
		for z in [-1.3, 1.3]:  # z negativo = frente
			_add_wheel(Vector3(x, 0.35, z), z < 0)


func set_lights(on: bool) -> void:
	for l in lights:
		l.visible = on


func _add_wheel(pos: Vector3, front: bool) -> void:
	var w := VehicleWheel3D.new()
	w.position = pos
	w.wheel_radius = 0.38
	w.wheel_rest_length = 0.15
	w.suspension_travel = 0.3
	w.suspension_stiffness = 45.0
	w.suspension_max_force = 8000.0
	w.damping_compression = 1.8
	w.damping_relaxation = 2.2
	w.wheel_friction_slip = 3.0
	w.use_as_steering = front
	w.use_as_traction = not front  # tração traseira
	var m := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.38
	cyl.bottom_radius = 0.38
	cyl.height = 0.25
	m.mesh = cyl
	m.rotation_degrees = Vector3(0, 0, 90)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.08, 0.08, 0.08)
	m.material_override = mat
	w.add_child(m)
	add_child(w)


func _physics_process(delta: float) -> void:
	engine_force = throttle * DRIVE_SIGN * 5500.0
	steering = move_toward(steering, steer * STEER_SIGN * 0.5, 2.5 * delta)
	brake = 12.0 if (absf(throttle) < 0.05 and linear_velocity.length() > 0.5) else 0.0
