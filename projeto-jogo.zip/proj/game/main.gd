extends Node3D
# Monta o mundo inteiro por código: mapa, luz, jogador, carro, câmera e controles.

const MAP_PATH := "res://map/rp_downtown_vv1.obj"
const SPAWN := Vector3(-50.12, -2.4, 34.11)  # info_player_start do mapa, já em metros

var player: CharacterBody3D
var car: VehicleBody3D
var cam: Camera3D
var controls: CanvasLayer
var in_car := false
var yaw := 0.0
var pitch := -0.25
var sky_mat: ProceduralSkyMaterial
var env: Environment
var sun: DirectionalLight3D
var game_hour := 10.0
var lamp_mats: Array = []


func _ready() -> void:
	_build_environment()
	_build_map()
	_build_city()

	player = preload("res://player.gd").new()
	add_child(player)
	player.global_position = SPAWN

	car = preload("res://car.gd").new()
	add_child(car)
	car.global_position = SPAWN + Vector3(5, 0.5, 0)

	cam = Camera3D.new()
	cam.far = 2200.0
	cam.near = 0.2
	add_child(cam)
	cam.current = true
	cam.global_position = SPAWN + Vector3(0, 3, 5)

	controls = preload("res://touch_controls.gd").new()
	add_child(controls)
	controls.look.connect(_on_look)
	controls.jump_pressed.connect(_on_jump)
	controls.action_pressed.connect(_toggle_car)
	controls.reset_pressed.connect(_reset_car)

	# Recursos extras: cada um é opcional (se algum script falhar, o resto continua).
	for path in ["res://traffic.gd", "res://hud.gd", "res://daynight.gd", "res://missions.gd"]:
		var sc = load(path)
		if sc != null:
			var node = sc.new()
			node.main = self
			if path == "res://hud.gd":
				node.name = "Hud"
			add_child(node)


# Mude para false se o jogo ficar pesado no seu celular.
const SHADOWS := true


func _build_environment() -> void:
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.22, 0.42, 0.74)
	sky_mat.sky_horizon_color = Color(0.68, 0.78, 0.88)
	sky_mat.ground_horizon_color = Color(0.68, 0.74, 0.80)
	sky_mat.ground_bottom_color = Color(0.30, 0.32, 0.35)
	sky_mat.sun_angle_max = 25.0
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.8
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.fog_enabled = true
	env.fog_light_color = Color(0.70, 0.78, 0.88)
	env.fog_density = 0.0018
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_color = Color(1.0, 0.94, 0.82)
	sun.light_energy = 1.25
	sun.shadow_enabled = SHADOWS
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 70.0
	sun.shadow_bias = 0.08
	sun.shadow_normal_bias = 1.5
	add_child(sun)


func _build_map() -> void:
	var mesh = load(MAP_PATH)
	if mesh == null or not (mesh is Mesh):
		push_error("Mapa não encontrado em " + MAP_PATH)
		return
	# Desliga o culling: se alguma face ficou virada ao contrário, ainda aparece.
	for i in range(mesh.get_surface_count()):
		var m = mesh.surface_get_material(i)
		if m is BaseMaterial3D:
			m.cull_mode = BaseMaterial3D.CULL_DISABLED
			m.roughness = 0.9
			m.metallic = 0.0
			m.metallic_specular = 0.15
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	add_child(mi)

	var body := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	shape.shape = mesh.create_trimesh_shape()
	body.add_child(shape)
	add_child(body)


func _build_city() -> void:
	var cd = load("res://city/city_data.gd")
	if cd == null:
		push_warning("Cidade não encontrada em res://city/")
		return
	for base in cd.SOLID:
		_add_chunk("res://city/%s.obj" % base, true, 1100.0)
	for base in cd.DECO:
		_add_chunk("res://city/%s.obj" % base, false, 380.0)
	_add_chunk("res://city/%s.obj" % cd.SCENERY, false, 0.0)  # colinas ao fundo, sempre visíveis


func _add_chunk(path: String, collide: bool, vis_end: float) -> void:
	var mesh = load(path)
	if mesh == null or not (mesh is Mesh):
		return
	for i in range(mesh.get_surface_count()):
		var m = mesh.surface_get_material(i)
		if m is BaseMaterial3D:
			m.cull_mode = BaseMaterial3D.CULL_DISABLED
			m.roughness = 0.9
			m.metallic = 0.0
			m.metallic_specular = 0.15
			if String(m.resource_name).begins_with("lamp_head"):
				m.emission_enabled = true
				m.emission = Color(1.0, 0.9, 0.6)
				m.emission_energy_multiplier = 0.5
				lamp_mats.append(m)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.visibility_range_end = vis_end
	add_child(mi)
	if collide:
		var body := StaticBody3D.new()
		var shape := CollisionShape3D.new()
		shape.shape = mesh.create_trimesh_shape()
		body.add_child(shape)
		add_child(body)


func focus_pos() -> Vector3:
	return car.global_position if in_car else player.global_position


func _on_jump() -> void:
	if not in_car:
		player.jump()


func _on_look(delta: Vector2) -> void:
	yaw -= delta.x * 0.005
	pitch = clamp(pitch - delta.y * 0.004, -1.2, 0.5)


func _toggle_car() -> void:
	if in_car:
		in_car = false
		var side := car.global_transform.basis.x * 2.5
		player.global_position = car.global_position + side + Vector3(0, 1.0, 0)
		player.set_active(true)
		car.throttle = 0.0
		car.steer = 0.0
	elif player.global_position.distance_to(car.global_position) < 5.0:
		in_car = true
		player.set_active(false)


func _reset_car() -> void:
	var p := player.global_position if not in_car else car.global_position
	car.linear_velocity = Vector3.ZERO
	car.angular_velocity = Vector3.ZERO
	car.global_transform = Transform3D(Basis(Vector3.UP, yaw), p + Vector3(0, 2.0, 0))


func _physics_process(delta: float) -> void:
	var mv: Vector2 = controls.move_vec
	if in_car:
		car.throttle = -mv.y
		car.steer = -mv.x
	else:
		player.move_input = mv
		player.cam_yaw = yaw
		if player.global_position.y < -60.0:
			player.global_position = SPAWN
			player.velocity = Vector3.ZERO

	var target: Vector3 = (car.global_position if in_car else player.global_position) + Vector3(0, 1.6, 0)
	var dist := 8.0 if in_car else 4.5
	var cam_basis := Basis.from_euler(Vector3(pitch, yaw, 0))
	var want := target + cam_basis * Vector3(0, 0, dist)
	cam.global_position = cam.global_position.lerp(want, clamp(12.0 * delta, 0.0, 1.0))
	cam.look_at(target, Vector3.UP)
