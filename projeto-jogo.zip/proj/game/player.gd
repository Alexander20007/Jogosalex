extends CharacterBody3D
# Jogador em terceira pessoa (cápsula colorida de placeholder).

const SPEED := 5.5
const JUMP := 7.0
const GRAVITY := 22.0

var move_input := Vector2.ZERO  # x = direita, y = frente(-)/trás(+)
var cam_yaw := 0.0
var _col: CollisionShape3D
var _mesh: MeshInstance3D


func _init() -> void:
	_col = CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	_col.shape = cap
	_col.position.y = 0.9
	add_child(_col)

	_mesh = MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.35
	cm.height = 1.8
	_mesh.mesh = cm
	_mesh.position.y = 0.9
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.9, 0.4, 0.1)
	_mesh.material_override = mat
	add_child(_mesh)


func set_active(on: bool) -> void:
	visible = on
	set_physics_process(on)
	_col.set_deferred("disabled", not on)
	if not on:
		velocity = Vector3.ZERO


func jump() -> void:
	if is_on_floor():
		velocity.y = JUMP


func _physics_process(delta: float) -> void:
	var dir := Basis(Vector3.UP, cam_yaw) * Vector3(move_input.x, 0, move_input.y)
	if dir.length() > 0.05:
		velocity.x = dir.x * SPEED
		velocity.z = dir.z * SPEED
		var target_yaw := atan2(-dir.x, -dir.z)
		rotation.y = lerp_angle(rotation.y, target_yaw, clamp(12.0 * delta, 0.0, 1.0))
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED * 4 * delta)
		velocity.z = move_toward(velocity.z, 0, SPEED * 4 * delta)
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	elif velocity.y < 0:
		velocity.y = 0
	floor_snap_length = 0.3
	move_and_slide()
