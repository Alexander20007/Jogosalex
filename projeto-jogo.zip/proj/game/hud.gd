extends CanvasLayer
# HUD: mini-mapa (norte para cima), relógio, dinheiro, missão e velocidade.

const MAP_SIZE := 190.0
const RANGE_M := 140.0
const BBOX := [-95.9, 61.8, -42.8, 80.8]  # área do mapa original (praça)

var main: Node3D
var money := 0
var mission_text := ""
var marker := Vector3.INF
var flash_text := ""
var flash_time := 0.0

var _map: Control
var _label: Label
var _flash: Label
var _nodes: Array = []
var _edges: Array = []
var _acc := 0.0


func _ready() -> void:
	layer = 5
	var cd = load("res://city/city_data.gd")
	if cd != null:
		_nodes = cd.NODES
		_edges = cd.EDGES

	_map = Control.new()
	_map.position = Vector2(20, 20)
	_map.size = Vector2(MAP_SIZE, MAP_SIZE)
	_map.clip_contents = true
	_map.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_map.draw.connect(_draw_map)
	add_child(_map)

	_label = _make_label(24)
	_label.position = Vector2(20, 20 + MAP_SIZE + 8)
	add_child(_label)

	_flash = _make_label(44)
	_flash.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_flash.offset_top = 40
	_flash.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_flash)


func _make_label(size: int) -> Label:
	var l := Label.new()
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	return l


func flash(text: String) -> void:
	flash_text = text
	flash_time = 2.5


func _process(delta: float) -> void:
	if main == null:
		return
	var hour: float = main.game_hour
	var txt := "%02d:%02d   $%d" % [int(hour) % 24, int((hour - floor(hour)) * 60.0), money]
	if mission_text != "":
		txt += "\n" + mission_text
	if main.in_car:
		txt += "\n%d km/h" % int(main.car.linear_velocity.length() * 3.6)
	_label.text = txt
	flash_time = max(0.0, flash_time - delta)
	_flash.text = flash_text if flash_time > 0.0 else ""
	_acc += delta
	if _acc > 0.05:
		_acc = 0.0
		_map.queue_redraw()


func _draw_map() -> void:
	if main == null:
		return
	var f: Vector3 = main.focus_pos()
	var fxz := Vector2(f.x, f.z)
	var sc := MAP_SIZE / (2.0 * RANGE_M)
	var half := Vector2(MAP_SIZE, MAP_SIZE) * 0.5
	_map.draw_rect(Rect2(Vector2.ZERO, Vector2(MAP_SIZE, MAP_SIZE)), Color(0.08, 0.10, 0.12, 0.8))
	var p0 := (Vector2(BBOX[0], BBOX[2]) - fxz) * sc + half
	_map.draw_rect(Rect2(p0, Vector2(BBOX[1] - BBOX[0], BBOX[3] - BBOX[2]) * sc), Color(0.45, 0.42, 0.34, 0.9))
	for e in _edges:
		var a := Vector2(float(_nodes[e[0]][0]), float(_nodes[e[0]][1]))
		var b := Vector2(float(_nodes[e[1]][0]), float(_nodes[e[1]][1]))
		var pa := (a - fxz) * sc + half
		var pb := (b - fxz) * sc + half
		if (pa - half).length() > MAP_SIZE * 1.3 and (pb - half).length() > MAP_SIZE * 1.3:
			continue
		_map.draw_line(pa, pb, Color(0.62, 0.62, 0.68), 6.0)
	if marker.is_finite():
		var m := (Vector2(marker.x, marker.z) - fxz) * sc
		var lim := MAP_SIZE * 0.5 - 8.0
		if absf(m.x) > lim or absf(m.y) > lim:
			m = m * (lim / maxf(absf(m.x), absf(m.y)))
		_map.draw_circle(half + m, 6.0, Color(1.0, 0.85, 0.1))
	var fwd3: Vector3 = -main.car.global_transform.basis.z if main.in_car else -main.player.global_transform.basis.z
	var fwd := Vector2(fwd3.x, fwd3.z)
	if fwd.length() < 0.01:
		fwd = Vector2(0, -1)
	fwd = fwd.normalized()
	var left := Vector2(-fwd.y, fwd.x)
	_map.draw_colored_polygon(PackedVector2Array([half + fwd * 10.0, half - fwd * 7.0 + left * 6.0, half - fwd * 7.0 - left * 6.0]), Color(1.0, 0.3, 0.2))
