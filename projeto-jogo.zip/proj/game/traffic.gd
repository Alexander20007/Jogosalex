extends Node3D
# Trânsito e pedestres simples (só visuais). Seguem o grafo de ruas de res://city/city_data.gd.
# Param quando o jogador está na frente. Se este script tiver erro, o jogo roda sem trânsito.

const CAR_COUNT := 45
const PED_COUNT := 60
const LANE_OFFSET := 2.25
const SIDEWALK_OFFSET := 9.0
const NEAR_RADIUS := 260.0
const FAR_RADIUS := 420.0

var main: Node3D
var nodes: Array = []
var adj: Dictionary = {}
var eoff: Dictionary = {}
var road_y := -3.658
var agents: Array = []
var _timer := 0.0


class Agent:
	var node: Node3D
	var a := 0
	var b := 0
	var t := 0.0
	var speed := 0.0
	var max_speed := 8.0
	var offset := 2.25
	var is_ped := false
	var lane_sign := 1.0


func _ready() -> void:
	var cd = load("res://city/city_data.gd")
	if cd == null:
		set_process(false)
		return
	nodes = cd.NODES
	road_y = cd.ROAD_Y
	for e in cd.EDGES:
		var a: int = e[0]
		var b: int = e[1]
		if not adj.has(a):
			adj[a] = []
		if not adj.has(b):
			adj[b] = []
		adj[a].append(b)
		adj[b].append(a)
		var lane := 2.25
		var side := 9.0
		if e.size() >= 4:
			lane = float(e[2])
			side = float(e[3])
		eoff[a * 100000 + b] = Vector2(lane, side)
		eoff[b * 100000 + a] = Vector2(lane, side)
	if adj.is_empty():
		set_process(false)
		return
	for i in range(CAR_COUNT):
		agents.append(_make_agent(false))
	for i in range(PED_COUNT):
		agents.append(_make_agent(true))
	for ag in agents:
		_place(ag, Vector3.ZERO)


func _node_pos(i: int) -> Vector3:
	return Vector3(float(nodes[i][0]), road_y, float(nodes[i][1]))


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	return m


func _make_agent(ped: bool) -> Agent:
	var ag := Agent.new()
	var n := Node3D.new()
	var col := Color.from_hsv(randf(), randf_range(0.3, 0.9), randf_range(0.4, 0.95))
	if ped:
		var mi := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.25
		cm.height = 1.7
		mi.mesh = cm
		mi.position.y = 0.85
		mi.material_override = _mat(col)
		n.add_child(mi)
		ag.max_speed = randf_range(1.1, 1.7)
		ag.is_ped = true
		ag.lane_sign = 1.0 if randf() < 0.5 else -1.0
	else:
		var body := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(1.8, 0.7, 4.2)
		body.mesh = bm
		body.position.y = 0.6
		body.material_override = _mat(col)
		n.add_child(body)
		var cabin := MeshInstance3D.new()
		var cb := BoxMesh.new()
		cb.size = Vector3(1.6, 0.55, 2.0)
		cabin.mesh = cb
		cabin.position = Vector3(0, 1.2, 0.3)
		cabin.material_override = _mat(Color(0.12, 0.17, 0.22))
		n.add_child(cabin)
		ag.max_speed = randf_range(6.0, 11.0)
		ag.offset = LANE_OFFSET
	add_child(n)
	ag.node = n
	ag.speed = ag.max_speed
	return ag


func _apply_edge(ag: Agent) -> void:
	var o: Vector2 = eoff.get(ag.a * 100000 + ag.b, Vector2(LANE_OFFSET, SIDEWALK_OFFSET))
	ag.offset = ag.lane_sign * o.y if ag.is_ped else o.x


func _place(ag: Agent, focus: Vector3) -> void:
	var keys: Array = adj.keys()
	var pick: int = keys[randi() % keys.size()]
	for i in range(40):
		var k: int = keys[randi() % keys.size()]
		var p := _node_pos(k)
		if Vector2(p.x - focus.x, p.z - focus.z).length() < NEAR_RADIUS or focus == Vector3.ZERO:
			pick = k
			break
	ag.a = pick
	var opts: Array = adj[pick]
	ag.b = opts[randi() % opts.size()]
	_apply_edge(ag)
	var A := _node_pos(ag.a)
	var B := _node_pos(ag.b)
	ag.t = randf() * A.distance_to(B)
	ag.speed = ag.max_speed
	var dir := (B - A).normalized()
	ag.node.global_position = A + dir * ag.t + dir.cross(Vector3.UP) * ag.offset


func _process(delta: float) -> void:
	if main == null:
		return
	var focus: Vector3 = main.focus_pos()
	_timer += delta
	var recycle := _timer > 1.0
	if recycle:
		_timer = 0.0
	for ag in agents:
		var A := _node_pos(ag.a)
		var B := _node_pos(ag.b)
		var seg := B - A
		var length := seg.length()
		if length < 0.01:
			_place(ag, focus)
			continue
		var dir := seg / length
		var to_focus := focus - ag.node.global_position
		to_focus.y = 0.0
		var d := to_focus.length()
		var want := ag.max_speed
		if d < 9.0 and d > 0.01 and dir.dot(to_focus / d) > 0.5:
			want = 0.0
		ag.speed = move_toward(ag.speed, want, 12.0 * delta)
		ag.t += ag.speed * delta
		if ag.t >= length:
			ag.t -= length
			var prev: int = ag.a
			ag.a = ag.b
			var opts: Array = adj[ag.a]
			var choices: Array = opts.filter(func(n): return n != prev)
			if choices.is_empty():
				choices = opts
			ag.b = choices[randi() % choices.size()]
			_apply_edge(ag)
			continue
		var right := dir.cross(Vector3.UP)
		var target := A + dir * ag.t + right * ag.offset
		ag.node.global_position = ag.node.global_position.lerp(target, clamp(10.0 * delta, 0.0, 1.0))
		var yaw := atan2(-dir.x, -dir.z)
		ag.node.rotation.y = lerp_angle(ag.node.rotation.y, yaw, clamp(8.0 * delta, 0.0, 1.0))
		if recycle and d > FAR_RADIUS:
			_place(ag, focus)
