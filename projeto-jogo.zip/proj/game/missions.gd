extends Node
# Entregas: vá até o marcador amarelo (a pé ou de carro) para ganhar dinheiro.

const REWARD := 100
const REACH := 9.0

var main: Node3D
var nodes: Array = []
var road_y := -3.658
var marker_node: MeshInstance3D
var hud
var target := Vector3.ZERO
var _acc := 0.0


func _ready() -> void:
	var cd = load("res://city/city_data.gd")
	if cd == null:
		set_process(false)
		return
	nodes = cd.NODES
	road_y = cd.ROAD_Y
	if nodes.is_empty():
		set_process(false)
		return
	marker_node = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 2.5
	cm.bottom_radius = 2.5
	cm.height = 80.0
	marker_node.mesh = cm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.85, 0.1, 0.35)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	marker_node.material_override = mat
	main.add_child.call_deferred(marker_node)
	hud = main.get_node_or_null("Hud")
	_new_mission()


func _new_mission() -> void:
	var f: Vector3 = main.focus_pos()
	var pick := randi() % nodes.size()
	for i in range(60):
		var k := randi() % nodes.size()
		var d := Vector2(float(nodes[k][0]) - f.x, float(nodes[k][1]) - f.z).length()
		if d > 250.0 and d < 900.0:
			pick = k
			break
	target = Vector3(float(nodes[pick][0]), road_y, float(nodes[pick][1]))
	marker_node.position = target + Vector3(0, 40, 0)
	if hud != null:
		hud.marker = target


func _process(delta: float) -> void:
	if main == null:
		return
	_acc += delta
	if _acc < 0.25:
		return
	_acc = 0.0
	var f: Vector3 = main.focus_pos()
	var d := Vector2(target.x - f.x, target.z - f.z).length()
	if hud != null:
		hud.mission_text = "Entrega: %d m" % int(d)
	if d < REACH:
		if hud != null:
			hud.money += REWARD
			hud.flash("+$%d  Entrega concluída!" % REWARD)
		_new_mission()
