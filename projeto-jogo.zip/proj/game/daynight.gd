extends Node
# Ciclo de dia e noite: sol, céu, neblina, lâmpadas dos postes e faróis do carro.

const DAY_SECONDS := 480.0  # 8 minutos reais por dia

var main: Node3D
var t := 0.42  # 0..1 (0.5 = meio-dia)


func _process(delta: float) -> void:
	if main == null or main.sun == null or main.env == null or main.sky_mat == null:
		return
	t = fposmod(t + delta / DAY_SECONDS, 1.0)
	var hour := t * 24.0
	main.game_hour = hour
	var ang := (hour - 6.0) / 12.0 * PI
	var elev := sin(ang)                        # -1 noite funda ... 1 meio-dia
	var night: float = 1.0 - smoothstep(-0.08, 0.22, elev)
	var warm: float = clampf(1.0 - absf(elev) / 0.35, 0.0, 1.0)

	main.sun.rotation_degrees = Vector3(-80.0 * elev, lerpf(-110.0, 40.0, clampf((hour - 6.0) / 12.0, 0.0, 1.0)), 0.0)
	main.sun.light_energy = lerpf(0.0, 1.25, 1.0 - night)
	main.sun.light_color = Color(1.0, 0.94, 0.82).lerp(Color(1.0, 0.55, 0.25), warm)

	var top := Color(0.22, 0.42, 0.74).lerp(Color(0.01, 0.02, 0.06), night)
	var hor := Color(0.68, 0.78, 0.88).lerp(Color(0.05, 0.06, 0.11), night).lerp(Color(0.95, 0.55, 0.30), warm * (1.0 - night * 0.5))
	main.sky_mat.sky_top_color = top
	main.sky_mat.sky_horizon_color = hor
	main.sky_mat.ground_horizon_color = hor
	main.sky_mat.ground_bottom_color = Color(0.30, 0.32, 0.35).lerp(Color(0.02, 0.02, 0.04), night)
	main.env.ambient_light_energy = lerpf(0.8, 0.28, night)
	main.env.fog_light_color = hor

	for m in main.lamp_mats:
		m.emission_energy_multiplier = lerpf(0.4, 4.0, night)
	if main.car != null and main.car.has_method("set_lights"):
		main.car.set_lights(night > 0.5)
