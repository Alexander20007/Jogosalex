extends CanvasLayer
# Controles de toque: analógico à esquerda, arrastar à direita = câmera.
# No computador (teste): WASD anda, mouse arrasta a câmera.

signal look(delta: Vector2)
signal jump_pressed
signal action_pressed
signal reset_pressed

var move_vec := Vector2.ZERO

var _stick_id := -1
var _look_id := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _buttons: Array[Button] = []
var _draw: Control
const RADIUS := 110.0


func _ready() -> void:
	layer = 10
	_draw = Control.new()
	_draw.set_anchors_preset(Control.PRESET_FULL_RECT)
	_draw.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_draw.draw.connect(_on_draw)
	add_child(_draw)

	_add_button("Pular", Vector2(-190, -260), func(): jump_pressed.emit())
	_add_button("Entrar / Sair", Vector2(-190, -170), func(): action_pressed.emit())
	_add_button("Resetar carro", Vector2(-190, -80), func(): reset_pressed.emit())


func _add_button(text: String, offset: Vector2, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(170, 70)
	b.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b.position = offset
	b.pressed.connect(cb)
	b.focus_mode = Control.FOCUS_NONE
	add_child(b)
	_buttons.append(b)
	b.anchor_left = 1.0
	b.anchor_right = 1.0
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.offset_left = offset.x
	b.offset_top = offset.y
	b.offset_right = offset.x + 170
	b.offset_bottom = offset.y + 70


func _over_button(p: Vector2) -> bool:
	for b in _buttons:
		if b.get_global_rect().has_point(p):
			return true
	return false


func _input(event: InputEvent) -> void:
	var half := get_viewport().get_visible_rect().size.x * 0.5
	if event is InputEventScreenTouch:
		if event.pressed:
			if _over_button(event.position):
				return
			if event.position.x < half and _stick_id == -1:
				_stick_id = event.index
				_stick_origin = event.position
				_stick_pos = event.position
			elif event.position.x >= half and _look_id == -1:
				_look_id = event.index
		else:
			if event.index == _stick_id:
				_stick_id = -1
				move_vec = Vector2.ZERO
				_draw.queue_redraw()
			elif event.index == _look_id:
				_look_id = -1
	elif event is InputEventScreenDrag:
		if event.index == _stick_id:
			_stick_pos = event.position
			var d := (_stick_pos - _stick_origin)
			move_vec = (d / RADIUS).limit_length(1.0)
			_draw.queue_redraw()
		elif event.index == _look_id:
			look.emit(event.relative)


func _process(_delta: float) -> void:
	if _stick_id == -1:  # teclado (teste no PC)
		var k := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
		var wasd := Vector2(
			float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)),
			float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
		move_vec = (k + wasd).limit_length(1.0)


func _on_draw() -> void:
	if _stick_id != -1:
		_draw.draw_circle(_stick_origin, RADIUS, Color(1, 1, 1, 0.15))
		_draw.draw_circle(_stick_origin + (_stick_pos - _stick_origin).limit_length(RADIUS), 40, Color(1, 1, 1, 0.45))
